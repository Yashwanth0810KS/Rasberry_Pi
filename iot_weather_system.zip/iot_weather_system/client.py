import requests
import socket
import json
import time

API_KEY = '03cd0ba68751fd92fa9a218e940bbdc8'
SERVER_IP = '192.168.43.153'  # Change to your Pi's IP
SERVER_PORT = 65432

def get_weather(city):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"
    response = requests.get(url)
    data = response.json()
    if response.status_code == 200:
        weather_data = {
            'temperature': data['main']['temp'],
            'pressure': data['main']['pressure'],
            'condition': data['weather'][0]['main']
        }
        return weather_data
    else:
        print(f"Failed to get weather data for {city}:", data.get("message", "Unknown error"))
        return None

def send_data(data):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((SERVER_IP, SERVER_PORT))
        s.sendall(json.dumps(data).encode('utf-8'))
        ack = s.recv(1024)
        print('Server ack:', ack.decode())

if __name__ == "__main__":
    city = input("Enter the city name: ").strip()
    while True:
        weather = get_weather(city)
        if weather:
            print(f"Sending weather data for {city}: {weather}")
            send_data(weather)
        else:
            print("Retrying in 1 minute...")
        time.sleep(300)  # Wait 5 minutes before next fetch