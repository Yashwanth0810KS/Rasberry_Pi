# IoT Weather Display & Alert System

## Overview
This project implements a Python-based client-server system where a laptop fetches real-time weather data from the OpenWeatherMap API and sends it to a Raspberry Pi 5 over Wi-Fi using socket communication.

The Raspberry Pi displays the received weather data on an SPI OLED (SSD1306) display and controls an LED based on the temperature threshold.

---

## System Components

### Laptop (Client)
- Fetches weather data for a specified city from OpenWeatherMap API.
- Extracts temperature (°C), pressure (hPa), and weather condition.
- Sends the data as a JSON string to the Raspberry Pi over TCP socket.

### Raspberry Pi 5 (Server)
- Listens for incoming socket connections.
- Receives and parses the JSON weather data.
- Displays temperature, pressure, and condition on an SPI-connected SSD1306 OLED display.
- Turns on an LED connected to GPIO26 if temperature exceeds 30°C.

---

## Requirements

### Laptop
- Python 3
- Libraries: `requests`, `socket`, `json`, `time`

### Raspberry Pi 5
- Python 3
- Libraries: `gpiozero`, `spidev`, `lgpio`, `Pillow`
- Hardware:
  - SSD1306 OLED display connected via SPI
  - LED connected to GPIO26

---

## Setup and Usage

### Client

1. Install dependencies:
   ```bash
   pip install requests
____________________________________________________________________________________________

2. Update client.py:

--> Enter your OpenWeatherMap API key.

--> Set the city name (can be input at runtime).

--> Set Raspberry Pi IP and port.

____________________________________________________________________________________________

3. Run client:
--> python client.py
The client will fetch weather every 5 minutes and send data to the server.

____________________________________________________________________________________________

Server
1. Install dependencies:

sudo apt-get install python3-pip
pip3 install gpiozero spidev Pillow lgpio

2. Connect the SSD1306 OLED display via SPI:

--> Reset pin: GPIO19

--> Data/Command pin: GPIO16

--> SPI bus 0, device 0

3. Connect LED to GPIO26.

4. Run server:

python server.py


____________________________________________________________________________________________

File Descriptions
client.py : Fetches weather data, sends to Raspberry Pi server.

server.py : Receives weather data, displays on OLED, controls LED.

README.md : This documentation.
____________________________________________________________________________________________